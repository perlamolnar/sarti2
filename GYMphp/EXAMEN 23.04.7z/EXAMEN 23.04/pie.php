<footer id="pie">
	<h3></h3>
	C/Desarrollador 77. <br>
	08880 Vilanova i la Geltrú, Barcelona <br>
	Tel: 777 888 999 <br>
	Email: perlamolnar@hotmail.com <br><br>
	Copyright is the primary intellectual property right protecting websites, and the purpose of a website copyright notice is to communicate information about copyright to users. This policy includes an assertion of copyright ownership.
</footer>