
<div id="home">
<h1>BIENVENIDOS AL MUNDO DE DEPORTES DE AVENTURA</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, dignissimos asperiores doloribus, voluptatem est eveniet enim dolores, odio voluptas corrupti harum quas. Voluptatum veniam quidem tempora doloremque delectus, provident iste. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Officia accusamus officiis consequuntur, in natus, ratione rem vel dignissimos vitae sunt quis quasi suscipit delectus? 
</p>
</div>


