<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>

<?php 
	include ("funcions.php");

?>

<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php 
	include("cfg.php");
	include("cabecera.php");
	include("body.php");
	include("pie.php");
?>

</body>
</html>