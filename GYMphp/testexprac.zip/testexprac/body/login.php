<form action="index.php" method="post" class="login">
  <div class="imgcontainer">
    <img style="width:10%" src="img/avatar.png" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="user" required>

    <label for="pass"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="pass" required>

    <button type="submit" name="login">Login</button>
  </div>
</form>