<div class="footer">
  <p>IMPORTANTE: Aunque esta Web en algunos aspectos -como el diseño Gráfico,control de errores- se queda justa, ya es bastante más de lo que pide el enunciado. RECORDAD: centraros en las funcionalidades que se os piden y no en el tema visual. Recordad el tiempo es límitado!! CAÑA! </p>
</div>